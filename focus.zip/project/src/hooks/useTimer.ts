import { useState, useEffect, useRef, useCallback } from 'react';
import { SessionType, Settings } from '../types';

interface UseTimerProps {
  settings: Settings;
  onComplete?: () => void;
  onTick?: (timeLeft: number) => void;
}

export function useTimer({ settings, onComplete, onTick }: UseTimerProps) {
  const [timeLeft, setTimeLeft] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const [sessionType, setSessionType] = useState<SessionType>('focus');
  const [currentSession, setCurrentSession] = useState(1);
  const intervalRef = useRef<NodeJS.Timeout>();

  const durations = {
    focus: settings.focusDuration * 60, // Convert minutes to seconds
    shortBreak: settings.shortBreakDuration * 60,
    longBreak: settings.longBreakDuration * 60,
  };

  const startTimer = useCallback((type: SessionType, duration?: number) => {
    const time = duration || durations[type];
    setTimeLeft(time);
    setSessionType(type);
    setIsRunning(true);
  }, [durations]);

  const pauseTimer = useCallback(() => {
    setIsRunning(false);
  }, []);

  const resumeTimer = useCallback(() => {
    setIsRunning(true);
  }, []);

  const resetTimer = useCallback(() => {
    setIsRunning(false);
    setTimeLeft(0);
  }, []);

  const skipTimer = useCallback(() => {
    setIsRunning(false);
    setTimeLeft(0);
    onComplete?.();
  }, [onComplete]);

  useEffect(() => {
    if (isRunning && timeLeft > 0) {
      intervalRef.current = setInterval(() => {
        setTimeLeft((prev) => {
          const newTime = prev - 1;
          onTick?.(newTime);
          
          if (newTime === 0) {
            setIsRunning(false);
            onComplete?.();
            
            // Auto-advance to next session
            if (sessionType === 'focus') {
              if (currentSession % settings.sessionsUntilLongBreak === 0) {
                setSessionType('longBreak');
                setTimeLeft(durations.longBreak);
              } else {
                setSessionType('shortBreak');
                setTimeLeft(durations.shortBreak);
              }
              setCurrentSession(prev => prev + 1);
            } else {
              setSessionType('focus');
              setTimeLeft(durations.focus);
            }
          }
          
          return newTime;
        });
      }, 1000);
    } else {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [isRunning, timeLeft, onComplete, onTick, sessionType, currentSession, durations, settings.sessionsUntilLongBreak]);

  const formatTime = useCallback((seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  }, []);

  const getProgress = useCallback(() => {
    const totalTime = durations[sessionType];
    return totalTime > 0 ? ((totalTime - timeLeft) / totalTime) * 100 : 0;
  }, [timeLeft, sessionType, durations]);

  return {
    timeLeft,
    isRunning,
    sessionType,
    currentSession,
    startTimer,
    pauseTimer,
    resumeTimer,
    resetTimer,
    skipTimer,
    formatTime,
    getProgress,
  };
}