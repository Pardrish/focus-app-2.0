import React from 'react';
import { Timer, ListTodo, Heart, BarChart3, Settings } from 'lucide-react';
import { AppTab } from '../../types';

interface BottomNavigationProps {
  activeTab: AppTab;
  onTabChange: (tab: AppTab) => void;
}

const navItems = [
  { id: 'timer' as const, icon: Timer, label: 'Timer' },
  { id: 'tasks' as const, icon: ListTodo, label: 'Tasks' },
  { id: 'wellness' as const, icon: Heart, label: 'Wellness' },
  { id: 'stats' as const, icon: BarChart3, label: 'Stats' },
  { id: 'settings' as const, icon: Settings, label: 'Settings' },
];

export function BottomNavigation({ activeTab, onTabChange }: BottomNavigationProps) {
  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-dark-800/95 backdrop-blur-lg border-t border-white/10 safe-area-bottom">
      <div className="flex items-center justify-around py-2 px-2 max-w-md mx-auto">
        {navItems.map(({ id, icon: Icon, label }) => {
          const isActive = activeTab === id;
          return (
            <button
              key={id}
              onClick={() => onTabChange(id)}
              className={`flex flex-col items-center justify-center p-3 rounded-xl transition-all duration-200 mobile-button ${
                isActive
                  ? 'text-coral-500 bg-coral-500/15 scale-105'
                  : 'text-gray-400 hover:text-gray-300 hover:bg-white/5 active:scale-95'
              }`}
            >
              <Icon 
                size={22} 
                className={`mb-1 transition-transform duration-200 ${
                  isActive ? 'scale-110' : 'scale-100'
                }`} 
              />
              <span className={`text-xs font-medium ${
                isActive ? 'text-coral-500' : 'text-gray-400'
              }`}>
                {label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}