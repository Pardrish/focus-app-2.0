import React from 'react';
import { ArrowLeft } from 'lucide-react';

interface HeaderProps {
  title: string;
  showBack?: boolean;
  onBack?: () => void;
  rightAction?: React.ReactNode;
}

export function Header({ title, showBack, onBack, rightAction }: HeaderProps) {
  return (
    <header className="flex items-center justify-between p-4 bg-dark-900/50 backdrop-blur-sm border-b border-white/10 safe-area-top">
      <div className="flex items-center">
        {showBack && (
          <button
            onClick={onBack}
            className="mr-3 p-3 rounded-xl hover:bg-white/10 transition-colors mobile-button"
          >
            <ArrowLeft size={22} className="text-white" />
          </button>
        )}
        <h1 className="text-xl font-semibold text-white">{title}</h1>
      </div>
      
      {rightAction && (
        <div className="flex items-center">
          {rightAction}
        </div>
      )}
    </header>
  );
}