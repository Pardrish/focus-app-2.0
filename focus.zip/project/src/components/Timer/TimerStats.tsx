import React from 'react';
import { Target, CheckCircle, Zap } from 'lucide-react';
import { Card } from '../UI/Card';

interface TimerStatsProps {
  focusSessions: number;
  tasksCompleted: number;
  dayStreak: number;
}

export function TimerStats({ focusSessions, tasksCompleted, dayStreak }: TimerStatsProps) {
  const stats = [
    {
      icon: Target,
      value: focusSessions,
      label: 'Focus Sessions',
      color: 'text-coral-500',
      bgColor: 'bg-coral-500/10',
    },
    {
      icon: CheckCircle,
      value: tasksCompleted,
      label: 'Tasks Done',
      color: 'text-blue-400',
      bgColor: 'bg-blue-400/10',
    },
    {
      icon: Zap,
      value: dayStreak,
      label: 'Day Streak',
      color: 'text-green-400',
      bgColor: 'bg-green-400/10',
    },
  ];

  return (
    <div className="grid grid-cols-3 gap-3 mt-8">
      {stats.map((stat, index) => (
        <Card key={index} className="text-center">
          <div className={`inline-flex p-2 rounded-lg ${stat.bgColor} mb-2`}>
            <stat.icon size={16} className={stat.color} />
          </div>
          <div className="text-xl font-bold text-white">{stat.value}</div>
          <div className="text-xs text-gray-400 mt-1">{stat.label}</div>
        </Card>
      ))}
    </div>
  );
}