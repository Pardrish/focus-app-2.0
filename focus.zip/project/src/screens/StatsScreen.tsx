import React from 'react';
import { Target, CheckCircle, Calendar, TrendingUp, Clock, Award } from 'lucide-react';
import { Header } from '../components/Layout/Header';
import { Card } from '../components/UI/Card';
import { useLocalStorage } from '../hooks/useLocalStorage';

export function StatsScreen() {
  const [stats] = useLocalStorage('app-stats', {
    focusSessions: 0,
    tasksCompleted: 0,
    dayStreak: 0,
    totalFocusTime: 0,
    completionRate: 0,
    averageSession: 0,
    weeklyGoal: 0,
  });

  const formatTime = (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    if (hours > 0) {
      return `${hours}h ${mins}m`;
    }
    return `${mins}m`;
  };

  const todayStats = [
    {
      icon: Target,
      value: stats.focusSessions,
      label: 'Focus Sessions',
      color: 'text-coral-500',
      bgColor: 'bg-coral-500/10',
    },
    {
      icon: CheckCircle,
      value: stats.tasksCompleted,
      label: 'Tasks Completed',
      color: 'text-green-400',
      bgColor: 'bg-green-400/10',
    },
    {
      icon: Calendar,
      value: stats.dayStreak,
      label: 'Day Streak',
      color: 'text-yellow-400',
      bgColor: 'bg-yellow-400/10',
    },
    {
      icon: TrendingUp,
      value: `${stats.completionRate}%`,
      label: 'Completion Rate',
      color: 'text-blue-400',
      bgColor: 'bg-blue-400/10',
    },
  ];

  return (
    <div className="min-h-screen dark-gradient pb-20">
      <Header title="Statistics" />

      <div className="px-4 py-6 max-w-md mx-auto">
        {/* Today's Overview */}
        <Card className="mb-6">
          <h2 className="text-lg font-semibold text-white mb-4">Today's Overview</h2>
          <div className="grid grid-cols-2 gap-4">
            {todayStats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className={`inline-flex p-3 rounded-full ${stat.bgColor} mb-3`}>
                  <stat.icon size={20} className={stat.color} />
                </div>
                <div className="text-2xl font-bold text-white mb-1">{stat.value}</div>
                <div className="text-sm text-gray-400">{stat.label}</div>
              </div>
            ))}
          </div>
        </Card>

        {/* Focus Time Details */}
        <Card className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-white">Focus Time</h2>
            <Clock size={20} className="text-coral-500" />
          </div>
          
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-gray-400">Total Focus Time</span>
              <span className="text-white font-semibold">
                {formatTime(stats.totalFocusTime)}
              </span>
            </div>
            
            <div className="flex justify-between items-center">
              <span className="text-gray-400">Average Session</span>
              <span className="text-white font-semibold">
                {formatTime(stats.averageSession)}
              </span>
            </div>
            
            <div className="flex justify-between items-center">
              <span className="text-gray-400">Weekly Goal</span>
              <span className="text-coral-500 font-semibold">
                {formatTime(stats.weeklyGoal)} / {formatTime(600)} {/* 10 hours goal */}
              </span>
            </div>
            
            {/* Progress bar */}
            <div className="w-full bg-gray-700 rounded-full h-2">
              <div 
                className="coral-gradient h-2 rounded-full transition-all duration-300"
                style={{ width: `${Math.min((stats.weeklyGoal / 600) * 100, 100)}%` }}
              ></div>
            </div>
          </div>
        </Card>

        {/* Task Progress */}
        <Card className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-white">Task Progress</h2>
            <CheckCircle size={20} className="text-green-400" />
          </div>
          
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-gray-400">Tasks Completed Today</span>
              <span className="text-white font-semibold">{stats.tasksCompleted}</span>
            </div>
            
            <div className="flex justify-between items-center">
              <span className="text-gray-400">Tasks This Week</span>
              <span className="text-white font-semibold">{stats.tasksCompleted * 3}</span>
            </div>
            
            <div className="flex justify-between items-center">
              <span className="text-gray-400">Completion Rate</span>
              <span className="text-green-400 font-semibold">{stats.completionRate}%</span>
            </div>
          </div>
        </Card>

        {/* Streak & Achievements */}
        <Card>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-white">Achievements</h2>
            <Award size={20} className="text-yellow-400" />
          </div>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
              <div className="flex items-center gap-3">
                <div className="text-2xl">🔥</div>
                <div>
                  <div className="text-white font-medium">Current Streak</div>
                  <div className="text-sm text-gray-400">{stats.dayStreak} days</div>
                </div>
              </div>
              <div className="text-xl font-bold text-coral-500">{stats.dayStreak}</div>
            </div>
            
            <div className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
              <div className="flex items-center gap-3">
                <div className="text-2xl">🏆</div>
                <div>
                  <div className="text-white font-medium">Focus Master</div>
                  <div className="text-sm text-gray-400">Complete 25 focus sessions</div>
                </div>
              </div>
              <div className="text-sm text-gray-400">
                {stats.focusSessions}/25
              </div>
            </div>
            
            <div className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
              <div className="flex items-center gap-3">
                <div className="text-2xl">⚡</div>
                <div>
                  <div className="text-white font-medium">Productivity Pro</div>
                  <div className="text-sm text-gray-400">Complete 50 tasks</div>
                </div>
              </div>
              <div className="text-sm text-gray-400">
                {stats.tasksCompleted}/50
              </div>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}