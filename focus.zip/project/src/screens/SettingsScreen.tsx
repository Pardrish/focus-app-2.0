import React from 'react';
import { 
  Palette, 
  Bell, 
  Volume2, 
  Shield, 
  Clock, 
  Smartphone,
  Moon,
  Sun,
  ChevronRight
} from 'lucide-react';
import { Header } from '../components/Layout/Header';
import { Card } from '../components/UI/Card';
import { Toggle } from '../components/UI/Toggle';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { Settings } from '../types';

export function SettingsScreen() {
  const [settings, setSettings] = useLocalStorage<Settings>('app-settings', {
    darkMode: true,
    notifications: true,
    soundEffects: true,
    strictMode: false,
    focusDuration: 25,
    shortBreakDuration: 5,
    longBreakDuration: 15,
    sessionsUntilLongBreak: 4,
    blockedApps: [],
  });

  const updateSetting = <K extends keyof Settings>(key: K, value: Settings[K]) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  const SettingItem = ({ 
    icon: Icon, 
    title, 
    description, 
    value, 
    onChange, 
    type = 'toggle',
    options = []
  }: {
    icon: any;
    title: string;
    description?: string;
    value: any;
    onChange: (value: any) => void;
    type?: 'toggle' | 'select' | 'button';
    options?: { value: any; label: string }[];
  }) => (
    <div className="flex items-center justify-between py-3">
      <div className="flex items-center gap-3 flex-1">
        <div className="p-2 bg-white/10 rounded-lg">
          <Icon size={18} className="text-coral-500" />
        </div>
        <div className="flex-1">
          <div className="text-white font-medium">{title}</div>
          {description && (
            <div className="text-sm text-gray-400 mt-1">{description}</div>
          )}
        </div>
      </div>
      
      {type === 'toggle' && (
        <Toggle checked={value} onChange={onChange} />
      )}
      
      {type === 'select' && (
        <select
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="px-3 py-1 bg-white/10 border border-white/20 rounded-lg text-white text-sm focus:outline-none focus:ring-2 focus:ring-coral-500/50"
        >
          {options.map((option) => (
            <option key={option.value} value={option.value} className="bg-dark-800">
              {option.label}
            </option>
          ))}
        </select>
      )}
      
      {type === 'button' && (
        <ChevronRight size={18} className="text-gray-400" />
      )}
    </div>
  );

  return (
    <div className="min-h-screen dark-gradient pb-20">
      <Header title="Settings" />

      <div className="px-4 py-6 max-w-md mx-auto space-y-6">
        {/* Appearance */}
        <Card>
          <div className="flex items-center gap-2 mb-4">
            <Palette size={20} className="text-coral-500" />
            <h2 className="text-lg font-semibold text-white">Appearance</h2>
          </div>
          
          <SettingItem
            icon={settings.darkMode ? Moon : Sun}
            title="Dark Mode"
            description="Toggle between light and dark themes"
            value={settings.darkMode}
            onChange={(value) => updateSetting('darkMode', value)}
          />
        </Card>

        {/* Notifications */}
        <Card>
          <div className="flex items-center gap-2 mb-4">
            <Bell size={20} className="text-coral-500" />
            <h2 className="text-lg font-semibold text-white">Notifications</h2>
          </div>
          
          <div className="space-y-1">
            <SettingItem
              icon={Bell}
              title="Enable Notifications"
              description="Get notified when timers complete"
              value={settings.notifications}
              onChange={(value) => updateSetting('notifications', value)}
            />
            
            <SettingItem
              icon={Volume2}
              title="Sound Effects"
              description="Play sounds for timer events"
              value={settings.soundEffects}
              onChange={(value) => updateSetting('soundEffects', value)}
            />
          </div>
        </Card>

        {/* Focus Mode */}
        <Card>
          <div className="flex items-center gap-2 mb-4">
            <Shield size={20} className="text-coral-500" />
            <h2 className="text-lg font-semibold text-white">Focus Mode</h2>
          </div>
          
          <div className="space-y-1">
            <SettingItem
              icon={Shield}
              title="Strict Lock Mode"
              description="Prevent navigation during focus sessions"
              value={settings.strictMode}
              onChange={(value) => updateSetting('strictMode', value)}
            />
            
            <SettingItem
              icon={Smartphone}
              title="Blocked Apps"
              description="Manage apps to block during focus"
              value={settings.blockedApps.length}
              onChange={() => {}}
              type="button"
            />
          </div>
        </Card>

        {/* Timer Settings */}
        <Card>
          <div className="flex items-center gap-2 mb-4">
            <Clock size={20} className="text-coral-500" />
            <h2 className="text-lg font-semibold text-white">Timer Settings</h2>
          </div>
          
          <div className="space-y-1">
            <SettingItem
              icon={Clock}
              title="Focus Duration"
              value={settings.focusDuration}
              onChange={(value) => updateSetting('focusDuration', parseInt(value))}
              type="select"
              options={[
                { value: 15, label: '15 minutes' },
                { value: 20, label: '20 minutes' },
                { value: 25, label: '25 minutes' },
                { value: 30, label: '30 minutes' },
                { value: 45, label: '45 minutes' },
                { value: 60, label: '60 minutes' },
              ]}
            />
            
            <SettingItem
              icon={Clock}
              title="Short Break"
              value={settings.shortBreakDuration}
              onChange={(value) => updateSetting('shortBreakDuration', parseInt(value))}
              type="select"
              options={[
                { value: 3, label: '3 minutes' },
                { value: 5, label: '5 minutes' },
                { value: 10, label: '10 minutes' },
                { value: 15, label: '15 minutes' },
              ]}
            />
            
            <SettingItem
              icon={Clock}
              title="Long Break"
              value={settings.longBreakDuration}
              onChange={(value) => updateSetting('longBreakDuration', parseInt(value))}
              type="select"
              options={[
                { value: 10, label: '10 minutes' },
                { value: 15, label: '15 minutes' },
                { value: 20, label: '20 minutes' },
                { value: 30, label: '30 minutes' },
              ]}
            />
            
            <SettingItem
              icon={Clock}
              title="Sessions until Long Break"
              value={settings.sessionsUntilLongBreak}
              onChange={(value) => updateSetting('sessionsUntilLongBreak', parseInt(value))}
              type="select"
              options={[
                { value: 2, label: '2 sessions' },
                { value: 3, label: '3 sessions' },
                { value: 4, label: '4 sessions' },
                { value: 5, label: '5 sessions' },
              ]}
            />
          </div>
        </Card>

        {/* App Info */}
        <Card>
          <div className="text-center py-4">
            <div className="text-coral-500 text-2xl mb-2">⏰</div>
            <h3 className="text-lg font-semibold text-white mb-1">Focus Flow</h3>
            <p className="text-sm text-gray-400 mb-2">Version 1.0.0</p>
            <p className="text-xs text-gray-500">
              Built with ❤️ for productivity
            </p>
          </div>
        </Card>
      </div>
    </div>
  );
}